# cav-guides
Repository to develop the 3 Problems.

## proj1/
Contains audiopy and imagepy packages with functions for audio and image/video respectively. Software developed for Problem 1.

## proj2/
Contains both lossy and lossless codecs for encoding and decoding of audio.
